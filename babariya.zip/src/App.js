import "./App.css";
import Response from "./components/Response";
function App() {
  return (
    <div className="App">
      <Response />
    </div>
  );
}

export default App;
