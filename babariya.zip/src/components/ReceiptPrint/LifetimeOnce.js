import React from 'react'

function LifetimeOnce() {
  return (
    <div>LifetimeOnce</div>
  )
}

export default LifetimeOnce