import React from 'react'

function LifetimeFree() {
  return (
    <div>LifetimeFree</div>
  )
}

export default LifetimeFree