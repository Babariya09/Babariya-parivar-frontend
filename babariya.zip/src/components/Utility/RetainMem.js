import React from 'react'

function RetainMem() {
  return (
    <div>RetainMem</div>
  )
}

export default RetainMem