import React from 'react'

function RemoveComm() {
  return (
    <div>RemoveComm</div>
  )
}

export default RemoveComm;