import React from 'react'

function AddComm() {
  return (
    <div>AddComm</div>
  )
}

export default AddComm;