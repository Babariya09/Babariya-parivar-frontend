import React from 'react'

function CreateUser() {
  return (
    <div>CreateUser</div>
  )
}

export default CreateUser