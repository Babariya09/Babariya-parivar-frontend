import React from 'react'

function SystemUser() {
  return (
    <div>SystemUser</div>
  )
}

export default SystemUser