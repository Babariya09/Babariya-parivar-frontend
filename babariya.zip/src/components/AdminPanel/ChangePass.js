import React from 'react'

function ChangePass() {
  return (
    <div>ChangePass</div>
  )
}

export default ChangePass