import React from 'react'

function BlankToken() {
  return (
    <div>BlankToken</div>
  )
}

export default BlankToken