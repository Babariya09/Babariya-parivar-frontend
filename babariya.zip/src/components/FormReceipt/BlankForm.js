import React from 'react'

function BlankForm() {
  return (
    <div>BlankForm</div>
  )
}

export default BlankForm